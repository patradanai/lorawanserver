Before submitting a bug report please
 - read the Troubleshooting documentation;
 - make sure you are running the latest stable release;
 - inspect the debug.log to check if there are some warnings or errors reported.
